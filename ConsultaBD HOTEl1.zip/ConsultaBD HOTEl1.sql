
WHERE usuario  = 'nombre_de_usuario_proporcionado' AND clave = 'clave_proporcionada';
#Insercciones para la tabla clientes
INSERT INTO tb_cliente (telefono)
VALUES ('0996723456'); 
INSERT INTO tb_cliente (nombre)
VALUES ('JUAN'); 
INSERT INTO tb_cliente (apellido)
VALUES ('RODRIGUEZ');
INSERT INTO tb_cliente (identificacion)
VALUES ('093478234-2'); 
#Consulto los clientes 
SELECT * FROM tb_cliente;
#Insercciones para la tabla forma de pago
INSERT INTO tb_forma_pago (transferencia_bancaria,pago_efectivo,paypal, estado)
VALUES ('Opcion 1', 'Opcion 2', 'Opcion 3',1);
#Consultar la forma de pago
SELECT * FROM tb_forma_pago; 
#Insercciones para la tabla habitacion
INSERT INTO tb_habitacion (numero,cupo,estado)
VALUES ("1", "5", 1)
#consultar la habitacion bd_veterinaria
SELECT * FROM tb_habitacion;
#Insercciones para la tabla hotel
INSERT INTO tb_hotel (nombre,direccion,descripcion,categoria,provincia,codgpostal,telefono,estado)
VALUES ('EXTASIS','DAULE', 'OFRECEMOS LOS MEJORES SERVICIOS',5 ,'GUAYAS','091902','0987654532', 1)
#Consultar el hotel
SELECT * FROM tb_hotel;
bd_veterinariabd_hotelbd_hotelbd_veterinariabd_hoteltb_clienteSELECT * FROM tb_hotel;
#Insercciones para la tabla orden de ingreso
INSERT INTO tb_propietario (nombre,apellido,cedula,edad,telefono, direccion,correo,estado)
VALUES ('JUAN CARLOS','AVILES ROMERO','0987653321', 40, '09887654433', 'Daule', 'juanaviles23@gmai.com',1)
#Consulto un propietario
SELECT * FROM tb_propietario;
#Insercciones para la tabla recepcionista
INSERT INTO tb_recepcionista (nombre_recepcionista,apellido,telefono,posicion,estado)
VALUES ('MARCOS', 'VILLAVICENCIO', '0977665423', 'OFRECER INFORMACION', 1)
#Consulto un recepcionista
SELECT * FROM tb_recepcionista;
#Insercciones para la tabla reserva
INSERT INTO tb_reserva (hora,fecha,comentario,precio)
VALUES ('11:00:00' , '2024-08-01', 'EXCELENTE SERVIVIO','20')
#Consulto una reserva
SELECT * FROM tb_reserva;
tb_forma_pagotb_transaccion
#Isercciones para la tabla transaccion 
INSERT INTO tb_transaccion (reservas,infor_pago,habitacion, estado)
VALUES (1,'SU PAGO A SIDO REGISTRADO', '4',1)
#Consulto la transaccion
SELECT * FROM tb_transaccion;
#Insercciones para la tabla usuario
INSERT INTO tb_usuario (nombre,clave,estado)
VALUES ('jazmin', 'vega', 1)
#Consulto el usuario
SELECT * FROM tb_usuario;
tb_propietariobd_hotelbd_hotel
tb_usuariotb_usuariotb_clientebd_hotelbd_veterinariabd_veterinariabd_hotelbd_hotelbd_hotelbd_veterinaria
bd_veterinariabd_hotelbd_hotelbd_hotelbd_hotelbd_hoteltb_cliente