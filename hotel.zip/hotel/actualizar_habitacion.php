<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$numero = $_POST ['numero'];
$cupo = $_POST ['cupo'];
$sql = "UPDATE tb_habitacion set numero = '$numero', cupo= '$cupo' where id_habitacion=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "habitacion.php"';
    echo '</script>' ;
    } 
?>
