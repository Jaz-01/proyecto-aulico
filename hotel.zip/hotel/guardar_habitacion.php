<?php 
include("configuracion.php");
$numero = $_POST['numero'];
$cupo = $_POST['cupo'];
$sql = "INSERT INTO tb_habitacion (numero,cupo) 
VALUES('$numero','$cupo')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="habitacion.php";';
	echo '</script>';	
}
?>