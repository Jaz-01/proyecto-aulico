<?php 
include("configuracion.php");
$transferencia_bancaria = $_POST['transferencia_bancaria'];
$pago_efectivo = $_POST['pago_efectivo'];
$paypal = $_POST['paypal'];
$sql = "INSERT INTO tb_forma_pago(transferencia_bancaria,pago_efectivo,paypal) 
VALUES('$transferencia','$pago_efectivo','$paypal')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="forma_pago.php";';
	echo '</script>';	
}
?>