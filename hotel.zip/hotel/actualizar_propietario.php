<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$apellido = $_POST ['apellido'];
$cedula = $_POST ['cedula'];
$edad  = $_POST ['edad'];
$telefono = $_POST ['telefono'];
$direccion = $_POST ['direccion'];
$correo = $_POST ['correo'];
$sql = "UPDATE tb_propietario set nombre = '$nombre', apellido= '$apellido', cedula ='$cedula', edad='$edad', telefono ='$telefono', direccion ='$direccion', correo ='$correo' where id_propietario=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "propietario.php"';
    echo '</script>' ;
    } 
?>
