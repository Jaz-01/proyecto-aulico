<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos</title>
</head>
<body>
    <!-- Creamos un menu     -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="hotel.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>HABITACION</h2>
    <hr>
    <!-- Creo un formulario para ingresar los datos -->
    <form action="registro_hotel.php" method="POST">
        <div class="container">
            <h1>nombre</h1>
            <input type="text" name="nombre" required>
            <h1>direccion</h1>
            <input type="text" name="direccion" required>
            <h1>descripcion</h1>
            <input type="text" name="descripcion" required>
            <h1>categoria</h1>
            <input type="text" name="categoria" required>
            <h1>provincia</h1>
            <input type="text" name="provincia" required>
            <h1>codgpostal</h1>
            <input type="text" name="codgpostal" required>
            <h1>telefono</h1>
            <input type="text" name="telefono" required>
            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>