<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$direccion = $_POST ['direccion'];
$descripcion = $_POST ['descripcion'];
$categoria = $_POST ['categoria'];
$provincia = $_POST ['provincia'];
$codgpostal= $_POST ['codgpostal'];
$identificacion = $_POST ['telefono'];
$sql = "UPDATE tb_hotel set nombre = '$nombre', direccion= '$direccion', descripcion='$descripcion', categoria='$categoria',provincia='$provincia', codgpostal='$codgpostal', identificacion='$identificacion'  where id_hotel=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "hotel.php"';
    echo '</script>' ;
    } 
?>