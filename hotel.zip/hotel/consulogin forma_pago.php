<?php
include("configuracion.php");

$nombre = $_POST['nombre'];
$clave = $_POST['clave'];

$query = "SELECT * FROM tb_usuario WHERE nombre = '$nombre' AND clave = '$clave'";
$result = mysqli_query($mysqli, $query);

if(mysqli_num_rows($result) > 0){
    header("Location: forma_pago.php");
} else {
    echo "Usuario o contraseña incorrectos";
}
?>
