<?php 
include("configuracion.php");
$telefono = $_POST['telefono'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$identificacion = $_POST['identificacion'];
$sql = "INSERT INTO tb_cliente(telefono,nombre,apellido,identificacion) 
VALUES('$telefono','$nombre','$apellido','$identificacion')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="cliente.php";';
	echo '</script>';	
}
?>