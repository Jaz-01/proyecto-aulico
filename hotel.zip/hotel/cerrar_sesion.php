<?php
    session_start();

    require 'configuracion.php';
    $_SESSION = array();

    session_destroy();

    header("Location: login.html");
    exit;
?>