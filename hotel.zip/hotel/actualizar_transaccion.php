<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$reservas = $_POST ['reservas'];
$infor_pago= $_POST ['infor_pago'];
$habitacion = $_POST ['habitacion'];
$sql = "UPDATE tb_transaccion set reservas = '$reseras', infor_pago= '$fecha', habitacion='$habitacion' where id_transaccion=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "reserva.php"';
    echo '</script>' ;
    } 
?