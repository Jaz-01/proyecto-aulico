<?php 
include("configuracion.php");
$id = $_GET['id'];
$sql ="UPDATE tb_transaccion SET estado = 0
WHERE id_transaccion = $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="transaccion.php";';
	echo '</script>';
	
}
?>