<?php
include ("configuracion.php");
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>MODIFICAR</title>
</head>
<body>
    <!-- Creamos un menu     -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="forma_pago.php"><i class="fa fa-user"></i></a>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <h2> ACTUALIZAR </h2>
        <form action="actualizar_forma_pago.php" method="POST">
        <div class="container">
            <?php
            //Preparamos la consulta
            $result = mysqli_query($mysqli, "SELECT * FROM tb_forma_pago WHERE id_forma_pago = $id");
            while($row = mysqli_fetch_array($result)){
                echo"<input type='hidden' name='id' value='{$row['id_forma_pago']}' required>";
                echo"<input type='text' name='transferencia_bancaria' value='{$row['transferencia_bancaria']}' required>";
                echo"<input type='text' name='pago_efectivo' value='{$row['pago_efectivo']}' required>";
                echo"<input type='text' name='paypal' value='{$row['paypal']}' required>";
                echo"<div class='clearfix'>";
                echo"<button type='submit' class='signupbtn'>Actualizar</button>";
                echo"</div>";    
            }
            ?>
        </div>
    </form>
    </div>
</body>
</html>