<?php 
include("configuracion.php");
$nombre = $_POST['nombre'];
$direccion = $_POST['direccion'];
$descripcion= $_POST['descripcion'];
$categoria = $_POST['categoria'];
$provincia = $_POST['provincia'];
$codgpostal = $_POST['codgpostal'];
$telefono = $_POST['telefono'];
$sql = "INSERT INTO tb_hotel(nombre,direccion,descripccion,categoria,provincia,codgpostal,telefono) 
VALUES($nombre','$direccion','$descripccion','$categoria','$provincia','$codgpostal','$telefono')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="hotel.php";';
	echo '</script>';	
}
?>