<?php 
include("configuracion.php");
$id = $_GET['id'];
$sql ="UPDATE tb_forma_pago SET estado = 0
WHERE id_forma_pago = $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="forma_pago.php";';
	echo '</script>';
	
}
?>