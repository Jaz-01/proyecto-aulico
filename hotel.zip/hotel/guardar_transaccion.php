<?php 
include("configuracion.php");
$reservas = $_POST['reservas'];
$infor_pago = $_POST['infor_pago'];
$habitacion = $_POST['habitacion'];
$sql = "INSERT INTO tb_transaccion(reservas,infor_pago,habitacion) 
VALUES('$reservas', '$infor_pago', 'habitacion')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="transaccion.php";';
	echo '</script>';	
}
?>