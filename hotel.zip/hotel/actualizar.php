<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$telefono = $_POST ['telefono'];
$nombre= $_POST ['nombre'];
$apellido = $_POST ['apellido'];
$identificacion = $_POST ['identificacion'];
$sql = "UPDATE tb_cliente set telefono = '$telefono', nombre= '$nombre', apellido='$apellido', identificacion='$identificacion' where id_cliente=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "cliente.php"';
    echo '</script>' ;
    } 
?>

