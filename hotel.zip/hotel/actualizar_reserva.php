<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$hora = $_POST ['hora'];
$nombre= $_POST ['nombre'];
$fecha = $_POST ['fecha'];
$comentario = $_POST ['comentario'];
$precio = $_POST ['precio'];
$sql = "UPDATE tb_reserva set hora = '$hora', fecha= '$fecha', comentario='$comentario', precio='$precio' where id_reserva=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "reserva.php"';
    echo '</script>' ;
    } 
?