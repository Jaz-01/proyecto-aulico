<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$transferencia_bancaria = $_POST ['transferencia_bancaria'];
$pago_efectivo = $_POST ['pago_efectivo'];
$paypal = $_POST ['paypal'];
$sql = "UPDATE tb_forma_pago set transferencia_bancaria = '$transferencia_bancaria', pago_efectivo= '$pago_efectivo', paypal='$paypal' where id_forma_pago=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "forma_pago.php"';
    echo '</script>' ;
    } 
?>
