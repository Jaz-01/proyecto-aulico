<?php
//Conexion
include ("configuracion.php");
$id = $_POST ['id'];
$nombre_recepcionista = $_POST ['nombre_recepcionista'];
$apellido = $_POST ['apellido'];
$telefono = $_POST ['telefono'];
$posicion= $_POST ['posicion'];
$sql = "UPDATE tb_recepcionista set  nombre= '$nombre', apellido='$apellido',telefono = '$telefono', posicion='$posicion' where id_recepcionista=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "recepcionista.php"';
    echo '</script>' ;
    } 
?>
