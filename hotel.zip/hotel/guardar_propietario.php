<?php 
include("configuracion.php");
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$edad= $_POST['edad'];
$telefono= $_POST['telefono'];
$direccion= $_POST['direccion'];
$correo= $_POST['correo'];
$cedula= $_POST['cedula'];
$sql = "INSERT INTO tb_propietario(nombre,apellido,edad,telefono,direccion,correo,cedula) 
VALUES('$telefono','$nombre','$apellido','$identificacion')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="propietario.php";';
	echo '</script>';	
}
?>