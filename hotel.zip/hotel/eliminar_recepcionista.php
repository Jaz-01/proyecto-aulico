<?php 
include("configuracion.php");
$id = $_GET['id'];
$sql ="UPDATE tb_recepcionista SET estado = 0
WHERE id_recepcionista = $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="recepcionista.php";';
	echo '</script>';
	
}
?>